﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoveYouALatte_Authentication.Models
{
    public class LatteModel
    {
        public int products_id { get; set; }
        public string product_name { get; set; }
        public decimal Price { get; set; }
    }
}
